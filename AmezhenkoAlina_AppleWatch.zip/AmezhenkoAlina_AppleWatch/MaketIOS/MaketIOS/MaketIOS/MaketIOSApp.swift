//
//  MaketIOSApp.swift
//  MaketIOS
//
//

import SwiftUI

@main
struct MaketIOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
