//
//  ContentView.swift
//  MaketIOS
//
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            Image("SplashScreen")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

