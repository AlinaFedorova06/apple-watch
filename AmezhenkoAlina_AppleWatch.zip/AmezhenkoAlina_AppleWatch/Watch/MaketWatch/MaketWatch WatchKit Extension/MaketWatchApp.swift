//
//  MaketWatchApp.swift
//  MaketWatch WatchKit Extension
//
//

import SwiftUI

@main
struct MaketWatchApp: App {
    @SceneBuilder var body: some Scene {
        WindowGroup {
            NavigationView {
                PageTwo()
            }
        }

        WKNotificationScene(controller: NotificationController.self, category: "myCategory")
    }
}
